package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {

    TextView display;
    String currentInput = "";
    String previousInput = "";
    String operator = "";
    double firstNumber = 0;
    boolean isNewOperation = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);

        // Number buttons
        setNumberButton(R.id.btn_0, "0");
        setNumberButton(R.id.btn_1, "1");
        setNumberButton(R.id.btn_2, "2");
        setNumberButton(R.id.btn_3, "3");
        setNumberButton(R.id.btn_4, "4");
        setNumberButton(R.id.btn_5, "5");
        setNumberButton(R.id.btn_6, "6");
        setNumberButton(R.id.btn_7, "7");
        setNumberButton(R.id.btn_8, "8");
        setNumberButton(R.id.btn_9, "9");
        setNumberButton(R.id.btn_decimal, ".");

        // Special buttons
        findViewById(R.id.btn_clear).setOnClickListener(v -> clearAll());
        findViewById(R.id.btn_plus_minus).setOnClickListener(v -> toggleSign());
        findViewById(R.id.btn_percent).setOnClickListener(v -> percent());
        findViewById(R.id.btn_bracket).setOnClickListener(v -> addBracket());

        // Operator buttons
        findViewById(R.id.btn_add).setOnClickListener(v -> setOperator("+"));
        findViewById(R.id.btn_subtract).setOnClickListener(v -> setOperator("−"));
        findViewById(R.id.btn_multiply).setOnClickListener(v -> setOperator("×"));
        findViewById(R.id.btn_divide).setOnClickListener(v -> setOperator("÷"));

        // Equals
        findViewById(R.id.btn_equals).setOnClickListener(v -> calculate());
    }

    private void setNumberButton(int id, String value) {
        findViewById(id).setOnClickListener(v -> {
            if (isNewOperation) {
                currentInput = "";
                isNewOperation = false;
            }
            if (value.equals(".") && currentInput.contains(".")) return;
            currentInput += value;
            updateDisplay();
        });
    }

    private void setOperator(String op) {
        if (!currentInput.isEmpty()) {
            firstNumber = Double.parseDouble(currentInput);
            operator = op;
            previousInput = currentInput + " " + op + " ";
            currentInput = "";
            isNewOperation = true;
            updateDisplay();
        } else if (!previousInput.isEmpty()) {
            // Allow changing operator
            previousInput = previousInput.substring(0, previousInput.length() - 2) + op + " ";
            operator = op;
            updateDisplay();
        }
    }

    private void calculate() {
        if (currentInput.isEmpty() || operator.isEmpty()) return;

        double secondNumber = Double.parseDouble(currentInput);
        double result = 0;

        switch (operator) {
            case "+": result = firstNumber + secondNumber; break;
            case "−": result = firstNumber - secondNumber; break;
            case "×": result = firstNumber * secondNumber; break;
            case "÷":
                if (secondNumber == 0) {
                    display.setText("Error");
                    return;
                }
                result = firstNumber / secondNumber;
                break;
        }

        // Format result (remove .0 if integer)
        if (result == (long) result) {
            display.setText(String.valueOf((long) result));
            currentInput = String.valueOf((long) result);
        } else {
            display.setText(String.valueOf(result));
            currentInput = String.valueOf(result);
        }

        previousInput = "";
        operator = "";
        isNewOperation = true;
    }

    private void clearAll() {
        currentInput = "";
        previousInput = "";
        operator = "";
        firstNumber = 0;
        isNewOperation = true;
        display.setText("0");
    }

    private void toggleSign() {
        if (!currentInput.isEmpty() && !currentInput.equals("0")) {
            if (currentInput.startsWith("-")) {
                currentInput = currentInput.substring(1);
            } else {
                currentInput = "-" + currentInput;
            }
            updateDisplay();
        }
    }

    private void percent() {
        if (!currentInput.isEmpty()) {
            double value = Double.parseDouble(currentInput) / 100;
            currentInput = value == (long) value ? String.valueOf((long) value) : String.valueOf(value);
            updateDisplay();
        }
    }

    private void addBracket() {
        // Simple bracket support (optional)
        currentInput += "(";
        updateDisplay();
    }

    private void updateDisplay() {
        String showText = previousInput + currentInput;
        if (showText.isEmpty()) showText = "0";
        if (showText.length() > 15) {
            display.setTextSize(40);
        } else {
            display.setTextSize(56);
        }
        display.setText(showText.isEmpty() ? "0" : showText);
    }
}